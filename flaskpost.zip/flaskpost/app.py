from enum import unique
from flask import Flask,render_template,request,redirect,session, flash, url_for
import flask_login
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin, login_manager, login_user, LoginManager, login_required, logout_user, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from flask_socketio import SocketIO, emit
app=Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///chatbox.db'
db = SQLAlchemy(app)
app.secret_key = 'my precious'

socketio =SocketIO(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class User(db.Model,UserMixin):
    id= db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20), nullable=False, unique=True)
    name = db.Column(db.VARCHAR(200), nullable=False)
    password = db.Column(db.VARCHAR(200), nullable=False)
    contactno = db.Column(db.VARCHAR(200), nullable=False)
    
    def __repr__(self):
        return '<Task %r>' % self.id



@app.route('/')
def index():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out sucessfully","info'")
    return redirect('/') 

@app.route('/login', methods=['POST','GET'])
def login():
    if request.method =='POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(username=email).first()
        if user:
            if check_password_hash(user.password, password):
            #if user.password==password:
                login_user(user)
                session['logged_in'] = True
                session['username'] =user.username
                session['id'] =user.id
                session['name'] =user.name
                session['contactno'] =user.contactno
                print("Username", flask_login.current_user)
                #print(session['username'])
                return redirect("/")
            else:
                return "Password Wrong"
        else:
            return "No Username exist"
    else:    
        return render_template('login.html')

@app.route('/register',methods=['POST','GET'])
def register():
    if request.method=='POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        hashed_password = password = generate_password_hash(password)
        contactno = request.form['contactno']
        user = User.query.filter(User.username==email).first()
        if not user:
            user = User(username=email,name=name, contactno=contactno, password=hashed_password )
            try:
                db.session.add(user)
                db.session.commit()
                return render_template("login.html", msg="User Registration Sucessfull")
            except Exception as e:
                return e
        else:
            return render_template("register.html",msg="User already exist.. Try again")
    else:   
        return render_template('register.html')

@app.route('/joinchat')
def joinchat():
    return render_template("joinchat.html")
    
@app.route('/chatroom')
def chatroom():
    return render_template("chatroom.html")
    

@app.route('/admin')
def admin():
    return render_template('admin.html')

@socketio.on('my_event')
def handle_my_custom_event(json):
    print("Msg Recieved from page: "+str(json) )
    socketio.emit('my_response', json)

if __name__ == "__main__":
    socketio.run(app,debug=True)